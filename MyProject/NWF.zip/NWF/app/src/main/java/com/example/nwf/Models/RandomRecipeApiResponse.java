package com.example.nwf.Models;

import java.util.ArrayList;

public class RandomRecipeApiResponse {
    public ArrayList<Recipe> recipes;
}
