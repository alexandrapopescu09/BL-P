package com.example.nwf.Models;

public class Us {
    public double amount;
    public String unitShort;
    public String unitLong;
}
