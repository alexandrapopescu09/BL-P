package com.example.nwf.Models;

public class Temperature {
    public double number;
    public String unit;
}
