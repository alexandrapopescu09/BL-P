package com.example.nwf.Models;

public class Equipment {
    public int id;
    public String name;
    public String localizedName;
    public String image;
    public Temperature temperature;
}
